import sys
import os
import re

class YareuLangInterpreter:
    def __init__(self, memory_size=30000):
        self.memory = [0] * memory_size
        self.pointer = 0
        self.clipboard = 0
        self.keywords = [
            '야르킁킁', '야르쫑긋', '야르덥석', '야르폴짝', '할렐야루',
            '야르꼴깍', '야르릉', '야르렁', '야르', '야', '르'
        ]
        self.regex_pattern = '|'.join(map(re.escape, self.keywords))

    def tokenize(self, source_code):
        return re.findall(self.regex_pattern, source_code)

    def build_jump_table(self, tokens):
        jump_table = {}
        stack = []
        for index, token in enumerate(tokens):
            if token == '야르쫑긋':
                stack.append(index)
            elif token == '야르꼴깍':
                if not stack:
                    raise SyntaxError(f"구문 오류: {index}번째 토큰 '야르꼴깍'과 일치하는 '야르쫑긋'이 없습니다.")
                start_index = stack.pop()
                jump_table[start_index] = index
                jump_table[index] = start_index
        if stack:
            raise SyntaxError("구문 오류: 닫히지 않은 '야르쫑긋'이 존재합니다.")
        return jump_table

    def execute(self, source_code):
        tokens = self.tokenize(source_code)
        if not tokens:
            return

        try:
            jump_table = self.build_jump_table(tokens)
        except SyntaxError as e:
            print(e, file=sys.stderr)
            sys.exit(1)

        pc = 0
        while pc < len(tokens):
            token = tokens[pc]

            if token == '야':
                self.pointer = (self.pointer + 1) % len(self.memory)
            elif token == '르':
                self.pointer = (self.pointer - 1) % len(self.memory)
            elif token == '야르':
                self.memory[self.pointer] = (self.memory[self.pointer] + 1) % 256
            elif token == '야르릉':
                self.memory[self.pointer] = (self.memory[self.pointer] - 1) % 256
            elif token == '야르렁':
                # 바이너리 스트림에 원시 바이트 그대로 기록
                sys.stdout.buffer.write(bytes([self.memory[self.pointer]]))
                sys.stdout.buffer.flush()
            elif token == '야르킁킁':
                char_input = sys.stdin.buffer.read(1)
                self.memory[self.pointer] = char_input[0] if char_input else 0
            elif token == '야르쫑긋':
                if self.memory[self.pointer] == 0:
                    pc = jump_table[pc]
            elif token == '야르꼴깍':
                if self.memory[self.pointer] != 0:
                    pc = jump_table[pc]
            elif token == '야르덥석':
                self.clipboard = self.memory[self.pointer]
            elif token == '야르폴짝':
                self.memory[self.pointer] = self.clipboard
            elif token == '할렐야루':
                break

            pc += 1

def main():
    # Windows 환경에서 실행될 경우의 터미널 및 입출력 스트림 환경 강제 정비
    if sys.platform == "win32":
        os.system("chcp 65001 > nul")
        # Python 3.7 이상에서 콘솔의 인코딩 충돌을 방지하기 위해 스트림을 utf-8로 재설정합니다.
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8')
        if hasattr(sys.stderr, 'reconfigure'):
            sys.stderr.reconfigure(encoding='utf-8')

    if len(sys.argv) < 2:
        print("사용법: python yareu.py <파일경로.yr>")
        sys.exit(1)

    file_path = sys.argv[1]
    if not file_path.endswith('.yr'):
        print("오류: .yr 확장자 파일만 실행할 수 있습니다.", file=sys.stderr)
        sys.exit(1)

    if not os.path.exists(file_path):
        print(f"오류: 파일을 찾을 수 없습니다: {file_path}", file=sys.stderr)
        sys.exit(1)

    with open(file_path, 'r', encoding='utf-8') as f:
        source_code = f.read()

    interpreter = YareuLangInterpreter()
    interpreter.execute(source_code)
